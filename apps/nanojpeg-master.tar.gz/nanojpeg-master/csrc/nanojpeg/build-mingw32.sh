P=mingw32 L="-s -static-libgcc" D=nanojpeg2.dll A=nanojpeg2.a ./build.sh
