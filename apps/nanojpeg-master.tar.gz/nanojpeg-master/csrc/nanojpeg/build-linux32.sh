P=linux32 L="-s -static-libgcc" D=libnanojpeg2.so A=libnanojpeg2.a ./build.sh
