P=linux64 C="-fPIC -include _memcpy.h" L="-s -static-libgcc" D=libnanojpeg2.so A=libnanojpeg2.a ./build.sh
