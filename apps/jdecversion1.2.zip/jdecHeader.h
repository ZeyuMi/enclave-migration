/*
  Software: Jpeg Decoder
  Version: 1.2
  Usage Info.: Every line in this software is written patiently only for the benefit of the community and myself who are willing to understand Jpeg. I am happy if this code is useful for you in some manner. I have no complaints if anyone uses this software for personal and non-commercial purpose. But an acknowledgement is greatly appreciated as it encourages me to do more upgrades.
  Author: Ram
  email : rammohan959[at]gmail.com 
  Release Date: 31th May 2012
*/

#ifndef DECHEADER_H
#define DECHEADER_H

#ifdef _MSC_VER
	#define _CRT_SECURE_NO_WARNINGS	
	#define INLINE __inline /* use __inline (VC++ specific) */
#else
	#define INLINE inline        /* use standard inline */
#endif

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdarg.h>
#include <assert.h>
#include <malloc.h>

#define MAXHUFFSIZE 512

typedef unsigned char unschar;
typedef unsigned int uint;
typedef struct tagAppArgs{					/*Input arguments*/
    char* szInputFile;
    char* szOutputFile;
	int scalefactor;
} AppArgs;
typedef struct tagDCHuffman{
	unschar BITS[2][16];					/*Number of Codes of Length I[1-16]*/
	unschar VALUES[2][16];					/*Code Values*/
	int CODE[2][16];						/*Huffman Code of the Values*/
	unschar SIZE[2][16];					/*Size Table*/
	int MAXCODE[2][16];						/*Maximum code of Length I[1-16]*/
	int MINCODE[2][16];						/*Minimum code of Length I[1-16]*/
	uint VALPTR[2][16];						/*Index of Maximum code of Length I[1-16] */
}DCHuffman;
typedef struct tagACHuffman{
	unschar BITS[2][16];					/*Number of Codes of Length I[1-16]*/
	unschar VALUES[2][MAXHUFFSIZE];			/*Code Values*/
	int CODE[2][MAXHUFFSIZE];				/*Huffman Code of the Values*/
	unschar SIZE[2][MAXHUFFSIZE];			/*Size Table*/
	int MAXCODE[2][16];						/*Maximum code of Length I[1-16]*/
	int MINCODE[2][16];						/*Minimum code of Length I[1-16]*/
	uint VALPTR[2][16];						/*Index of Maximum code of Length I[1-16] */
}ACHuffman;
typedef enum tagYUVFormat{					/*Internal Color Format*/
	YUV400 = 0,
	YUV420 = 1,
	YUV422 = 2,
	YUV444 = 3
}YUVFormat;
typedef struct tagOutputStream{				/*Output Buffer*/
	unschar *streamY,*streamU,*streamV;
	uint indexY[2],indexU[2],indexV[2];
}OutputStream;
typedef struct tagInputStructure{
	unschar* rawData;						/*Input Buffer*/
	unschar soi,eoi;						/* Start of Image, End of Image */
	uint inputAttributes[3];				/*Width,Height,Depth*/
	unschar nf,ns;							/*Number of Frame Components & Scan Components*/
	unschar* componentAttributes;			/*Component Attributes*/
	unschar quantTables[4][64];				/*Quant Tables*/
	uint restartInterval;					/*Restart Interval*/
	DCHuffman dcCode;						/*Huffman Codes*/
	ACHuffman acCode;
	YUVFormat inputFormat;					/*Encoded Format*/
	uint expectedMCUCount;					/*Expected MCU Count*/
	unschar multiScan;						/*Scan Component Index[7bits]|multiScan[1bit]*/
	OutputStream out;						/*Output Buffer*/
	uint extwidth,extheight;				/*extended width, height*/
	unschar DNL;							/*This register is set if DNL marker is present*/
	int scalefactor;						/*down scale the image by 'K' along width & height [K = 1|2|4|8]*/
}InputStructure;

/*Function prototypes*/
extern int DecompressImage(InputStructure*);
extern int CleanUp(InputStructure*);
extern INLINE int markerSKIP(unschar **);

#endif