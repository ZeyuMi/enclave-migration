/*
  Software: Jpeg Decoder
  Version: 1.2
  Usage Info.: Every line in this software is written patiently only for the benefit of the community and myself who are willing to understand Jpeg. I am happy if this code is useful for you in some manner. I have no complaints if anyone uses this software for personal and non-commercial purpose. But an acknowledgement is greatly appreciated as it encourages me to do more upgrades.
  Author: Ram
  email : rammohan959[at]gmail.com 
  Release Date: 31th May 2012
*/

#include "jdecHeader.h"

/*
If you have an OpenCV library, enable the definition OPEN_CV_ENABLE.

<Additional Include files used are>
cv.h, cxcore.h, highgui.h
<Location of include files>
"<your path>\OpenCV\cv\include";
"<your path>\OpenCV\cxcore\include";
"<your path>\OpenCV\otherlibs\highgui";
"<your path>\OpenCV\otherlibs\cvcam\include";
"<your path>\OpenCV\cvaux\include"

<Additional Link Libraries used are>
cv.lib, cxcore.lib, highgui.lib
<Location of libraries>
<your path>\OpenCV\lib
*/

#ifdef OPEN_CV_ENABLE

#include <cv.h>
#include <cxcore.h>
#include <highgui.h>

static int ViewImage(AppArgs *args, InputStructure *input){
	// This function uses multiple OpenCV library functions. The sole purpose is to view the decoded image.
	IplImage *img = NULL;
	CvScalar s;
	uint i = 0 ,j = 0;
	uint width = input->inputAttributes[0], height = input->inputAttributes[1];

	width = ((width + input->scalefactor - 1)/ input->scalefactor);
	height = ((height + input->scalefactor - 1)/ input->scalefactor);

	img=cvCreateImage(cvSize(width,height),input->inputAttributes[2],input->nf);
	for (i=0;i<height*input->scalefactor;i+=input->scalefactor){
		for(j=0;j<width*input->scalefactor;j+=input->scalefactor){
			if (input->nf == 1)
				s.val[0]=(double)input->out.streamY[i*input->extwidth+j];	// Luminance
			if (input->nf == 3){			
				s.val[0]=(double)input->out.streamV[i*input->extwidth+j];	// expects BGR input
				s.val[1]=(double)input->out.streamU[i*input->extwidth+j];
				s.val[2]=(double)input->out.streamY[i*input->extwidth+j];
			}
			cvSet2D(img,i/input->scalefactor,j/input->scalefactor,s); // set the (i,j) pixel value
		}
	}
	cvNamedWindow(args->szInputFile, 1);
	if (width > 800 || height > 600){
		// In cases where the width and height are too large for best viewing effects it is better to resize the original image
		IplImage *destination = NULL;
		int factor = 0;

		printf("The image is resized for viewing convenience \n" "[Width, Height] :: [%d, %d]->", width, height);
		factor = (width/800 + 1), width /= factor;
		factor = (height/600 + 1), height /= factor;
		printf("[%d, %d]", width, height);

		destination = cvCreateImage(cvSize(width,height),input->inputAttributes[2],input->nf);
		cvResize(img,destination,CV_INTER_AREA);
		cvShowImage(args->szInputFile, destination);
		cvReleaseImage( &destination );
	}
	else
		cvShowImage(args->szInputFile, img);	
	cvWaitKey(0);	//wait for key to close the window
	cvDestroyWindow( args->szInputFile );
	cvReleaseImage( &img );
	return 0;
}
#endif

int CleanUp(InputStructure *input){
	// Prevents Memory leaks	
	if (!input->rawData) free(input->rawData);
	if (!input->componentAttributes) free(input->componentAttributes);
	if (!input->out.streamY) free(input->out.streamY);
	if (!input->out.streamU) free(input->out.streamU);
	if (!input->out.streamV) free(input->out.streamV);

	return 0;
}

static int InttoStr(int a,char *string){
	// This function is equivalent to itoa()
	int x=10, i=1;

	assert (a >= 0);

	while ( a > (x-1)){
		x = x*10;
		i++;		
	}
	x = i-1;
	while (x >= 0){		
		string[x] = (48+(a%10));
		a /= 10;
		x--;
	}
	string[i] = '\0';

	return 0;
}

static int OutputFileWrite(AppArgs *args,InputStructure *input) {
	// This function writes the data in the output buffer to a ppm/pgm file	
	// gray images expects file names with extension pgm
	// color images expects file names with extension ppm
	FILE *ofp = NULL;	
	
	ofp = fopen(args->szOutputFile,"wb");
	if (ofp){		
		uint i = 0,j = 0;		
		char ppmarray[20]={'\0'};
		uint width = input->inputAttributes[0], height = input->inputAttributes[1];

		width = ((width + input->scalefactor - 1)/ input->scalefactor);
		height = ((height + input->scalefactor - 1)/ input->scalefactor);

		if (input->nf == 1)
			fwrite("P5 ",sizeof(char),strlen("P5 "),ofp);		// PGM
		else
			fwrite("P6 ",sizeof(char),strlen("P6 "),ofp);		// PPM	
		
		InttoStr(width,ppmarray);			// Width		
		fwrite(ppmarray,sizeof(char),strlen(ppmarray),ofp);
		fwrite("\n",sizeof(char),strlen("\n"),ofp);
		
		InttoStr(height,ppmarray);			// Height
		fwrite(ppmarray,sizeof(char),strlen(ppmarray),ofp);
		fwrite("\n",sizeof(char),strlen("\n"),ofp);
		
		InttoStr(255,ppmarray);				// Bit-Depth
		fwrite(ppmarray,sizeof(char),strlen(ppmarray),ofp);
		fwrite("\n",sizeof(char),strlen("\n"),ofp);
		// PPM/PGM Header Write
		
		for (j=0;j<height*input->scalefactor;j+=input->scalefactor){
			for (i=0;i<width*input->scalefactor;i+=input->scalefactor){
				fwrite(input->out.streamY+j*input->extwidth+i,sizeof(char),1,ofp);
				if (input->nf == 3){
					fwrite(input->out.streamU+j*input->extwidth+i,sizeof(char),1,ofp);
					fwrite(input->out.streamV+j*input->extwidth+i,sizeof(char),1,ofp);					
				}
			}
		}
		// PPM Content write
		fclose(ofp);
	}
	else{
		CleanUp(input);
		printf("stderr :: Unable to open file %s ",args->szOutputFile);
		exit(1);
	}
	return 0;
}

static int DNL(unschar **ipPtr,InputStructure *input){	
	// DNL Marker constitutes the height of the encoded image.
	int Length = 0;
	
	Length = (**ipPtr * 256)+(*((*ipPtr)+1));
	(*ipPtr) += 2;
	assert (Length == 4);
	input->inputAttributes[1] =  (**ipPtr * 256)+(*((*ipPtr)+1));	// Height
	(*ipPtr) += 2;

	return 0;
}

INLINE int markerSKIP(unschar **InPtr){
	// Encountered a marker, Do nothing. Just Skip ahead.
	(*InPtr) += (256*(**InPtr) + *(*InPtr+1));
	return 0;
}

static int InitInput (InputStructure *input, AppArgs *args){
	// Reset the input structure for smooth execution
	unschar *ipPtr = input->rawData;
	int count = 0,i = 0,noofScans = 0;

	input->eoi = 0;	
	input->soi = 0;	
	input->componentAttributes = NULL;
	input->multiScan = 0;
	input->DNL = 0;
	input->scalefactor = args->scalefactor;

	/* Huffman DC, AC BITS and VAL Reset */
	for (count=0;count<2;count++){
		for (i=0;i<16;i++){
			input->dcCode.BITS[count][i] = 0;
			input->dcCode.VALUES[count][i] = 0;
			input->acCode.BITS[count][i] = 0;
		}
	}
	for (count=0;count<2;count++){
		for (i=0;i<MAXHUFFSIZE;i++){
			input->acCode.VALUES[count][i] = 0;
		}
	}

	/*Output Stream Pointer Initialization*/
	input->out.indexY[0] = input->out.indexY[1] = 0;
	input->out.indexU[0] = input->out.indexU[1] = 0;
	input->out.indexV[0] = input->out.indexV[1] = 0;
	input->out.streamY = input->out.streamU = input->out.streamV = NULL;

	/*DNL Marker Support*/
	/*The height of an image is declared in the marker SOI. But it so happens sometimes in multi-scan images, the height is declared after the occurence of first scan under the marker DNL. Hence the correct height information is not known until the first scan is completely decoded. To avoid this wait we look in to the entire image ahead for DNL and extract the actual height of the image.*/
	while(noofScans < 2){
		if (*ipPtr == 0xff){
			// Stand Alone Marker(s)
			if ( (*(ipPtr+1) == 0x00) || ((*(ipPtr+1) >= 0xd0) && (*(ipPtr+1) <= 0xd8)))
				ipPtr += 2;
			// Stuff Byte
			else if (*(ipPtr+1) == 0xff)
				ipPtr += 1;
			// EOI Marker
			else if (*(ipPtr+1) == 0xd9)
				noofScans = 2;				
			else{
				// DNL Marker
				if (*(ipPtr+1) == 0xdc){					
					ipPtr += 2;
					DNL(&ipPtr,input);
					input->DNL = 1;
					noofScans = 2;
				}				
				else{
					// Start of Scan Marker
					if (*(ipPtr+1) == 0xda)
						noofScans++;
					ipPtr += 2;
					markerSKIP(&ipPtr);
				}
			}			
		}
		else
			ipPtr++;
	}
	return 0;
}

static int InputFileRead(AppArgs *args, InputStructure *input) {
	// This function reads input file (jpeg) in to a buffer
	FILE *ifp = NULL;

	ifp = fopen(args->szInputFile,"rb");
	if (ifp){
		long int fsize;
		fseek(ifp, 0, SEEK_END);
		fsize=ftell(ifp);
		fseek(ifp, 0, SEEK_SET);
		input->rawData =(unschar*) malloc(fsize*sizeof(unschar));
		if (NULL == input->rawData){
			printf("stderr :: Unable to allocate memory for the input image");
			exit(1);
		}
		else{ 
			if (fsize != fread(input->rawData, sizeof(char), fsize, ifp)){
				printf("stderr :: file read %s is unsuccessful",args->szInputFile);
				free(input->rawData);
				exit(1);
			}
		}
		fclose(ifp);
	}
	else{
		printf("stderr :: Unable to open file %s",args->szInputFile);
		exit(1);
	}
	return 0;
}

static int AppInitDefaultArgs(AppArgs *args){
	// Default initialization of input arguments
	args->szInputFile=NULL;
	args->szOutputFile="out.ppm";
	args->scalefactor=1;

	return 0;
}

static int AppParseArgs(int argc, char *argv[], AppArgs *args){
	int i = 1;
	if ((argc-1)%2 != 0){
		// every actual argument that is passed to the executable needs to be paired with a switch
		printf("stderr :: Perhaps a switch or its argument is missing.");
		exit(1);
	}
	AppInitDefaultArgs(args);
	while (i < argc){
		if (argv[i][0] == '-'){
			// Every switch has to begin with the hyphen character
			switch (argv[i][1]){
				case 'i':
					args->szInputFile=argv[i+1];
					break;
				case 'o':
					args->szOutputFile=argv[i+1];
					break;
				case 's':
					args->scalefactor=atoi(argv[i+1]);
					break;
				default:
					printf("stderr ::switch %s is invalid, ",argv[i]);
					exit(1);
			}
		}
		else{
			printf("stderr :: perhaps '-' is missing for a switch %s, ",argv[i]);
			exit(1);
		}			
		i += 2;
	}
	return 0;
}

static int AppUsage(const char *exe){
	// List command line parameters
	printf("\n");
    printf("%s [options]..." "\n", exe);
    printf("Expects options in the form of -<switch> <Argument>" "\n");
    printf("\t -i input filename [*.jpg/jpeg]" "\n");
    printf("\t -o output filename [*.ppm/pgm]" "\n");
	printf("\t -s down scale the image by 'K' along width & height [K = 1, 2, 4, 8]" "\n");
	return 0;
}
int main(int argc, char *argv[]){

	if (1 == argc){
		// List command line parameters
		AppUsage(argv[0]);
	}
	else{
		// Input arguments are parsed and stored in the structure AppArgs
		AppArgs args = {NULL};
		// Input Structure contains the information necessary to perform decoding
		InputStructure input = {NULL};

		// Parse command line parameters
		AppParseArgs(argc, argv, &args);

		// Read Input Jpeg File
		InputFileRead(&args,&input);

		// This function Sets initial Values for Smooth execution 
		InitInput(&input, &args);

		// Decompress Image
		DecompressImage(&input);

		// Write Output File
		OutputFileWrite(&args,&input);

#ifdef OPEN_CV_ENABLE
		// View image
		ViewImage(&args,&input);
#endif
		// Clean up
		CleanUp(&input);

	}	
	return 0;
}