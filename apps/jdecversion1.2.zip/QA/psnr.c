/* ========================================================================== */
/*                                                                            */
/*   PSNR.c                                                                   */
/*   (c) 2001 Ram Mohan M                                                     */
/*                                                                            */
/*   Description: Computes the PSNR between two images of bit width = 8       */
/*                                                                            */
/* ========================================================================== */

#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int main (int argc, char **argv){
	FILE *ifp_ref, *ifp_inp;
	unsigned int width, height,i;
	unsigned char *refBuffer, *inpBuffer;
	double diff[3]={0.0,0.0,0.0};
	const int K = 3;

	if (argc != 5){
		printf("Insufficient args\n"
			"usage:\nargv[0] = psnr.exe\n"
			"argv[1] : reference file name\n"
			"argv[2] : Name of file under test\n"
			"argv[3] : width\n"
			"argv[4] : height\n");
		exit(0);
	}
	ifp_ref = fopen(argv[1],"rb");
	ifp_inp = fopen(argv[2],"rb");
	if (ifp_ref == NULL || ifp_inp == NULL){
		printf("Unable to open the input file(s) provided");
		exit(1);
	}
	width = atoi(argv[3]);
	height = atoi(argv[4]);
	refBuffer = (unsigned char *)calloc(width*height*K,sizeof(unsigned char));
	inpBuffer = (unsigned char *)calloc(width*height*K,sizeof(unsigned char));
	if (inpBuffer == NULL || refBuffer == NULL){
		printf("Unable to allocate Memory");
		exit(1);
	}
	if ( (fread(refBuffer,sizeof(unsigned char),width*height*K,ifp_ref)== width*height*K) && 
		(fread(inpBuffer,sizeof(unsigned char),width*height*K,ifp_inp) == width*height*K)){
			for (i=0;i<width*height*K;i+=3){
				diff[0] += ((refBuffer[i] - inpBuffer[i]) * (refBuffer[i] - inpBuffer[i]));
				diff[1] += ((refBuffer[i+1] - inpBuffer[i+1]) * (refBuffer[i+1] - inpBuffer[i+1]));
				diff[2] += ((refBuffer[i+2] - inpBuffer[i+2]) * (refBuffer[i+2] - inpBuffer[i+2]));
			}
			for(i=0;i<K;i++){
				diff[i] = diff[i]/(width*height);
				diff[i] = 10 * log10((255*255)/diff[i]);
			}
			printf("%f\t%f\t%f\n",diff[0],diff[1],diff[2]); 
			// printf("%f\t",diff[0]); 
	}
	else{
		printf("file read error");
	}
	fclose(ifp_ref);
	fclose(ifp_inp);
	free(refBuffer);
	free(inpBuffer);
	return 0;
}